Author: Cole Moore
Course: CS 316
Project: Programming Assignment 4
        Back End Web Development

Run using 'node PA4.js'.

Throughout my code, I have left NOTEs that can be found using the find tool.

Line 22: Feel free to comment out the default user that I implemented; 
it is strictly for testing purposes and not necessary for the code to work.

Line 140 & 152: I got stuck on how to implement methods for 
finding if the username has been used already.

Line 243: Potentially for extra credit, although I'm not sure if it is covered since the email
cannot be changed, the username and the phone number can be altered infinitely. However, the
email has to remain the same; otherwise, it will render the 404 page.