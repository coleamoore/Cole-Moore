import display

#Check if pyraminx is solved (all sides are a solid color (in initial state))
def check(pyraminx):
    if pyraminx == ['r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g']:
        return True
    else:
        return False

#Print out all possible moves
def moveset():
    print("The first letter stands for the position of the tips relative to the front-facing blue side.")
    print("The number after the letter represents how many levels from that tip down will be rotated per move.")
    print("NOTE: ALL ROTATIONS WILL BE COUNTERCLOCKWISE RELATIVE TO THE TIP CHOSEN")
    print("T: top")
    print("T1")
    print("T2")
    print("T3")
    print("L: left")
    print("L1")
    print("L2")
    print("L3")
    print("R: right")
    print("R1")
    print("R2")
    print("R3")
    print("B: back")
    print("B1")
    print("B2")
    print("B3")

#Node class
class Node():

    def __init__(self, move=None):
        self.move = move
        self.f = None

#Calculates f value and stores it in node with the move number, which is put into open list
def astar(pyraminx, g, open_list, closed_list, movement):
    total_incorrect = 0

    for r in range(0, 16):
        if pyraminx[r] != "r":
            total_incorrect += 1

    for b in range(16, 32):
        if pyraminx[b] != "b":
            total_incorrect += 1

    for y in range(32, 48):
        if pyraminx[y] != "y":
            total_incorrect += 1

    for gr in range(48, 64):
        if pyraminx[gr] != "g":
            total_incorrect += 1

    #print(total_incorrect)
    h = total_incorrect / 12
    f = g + h
    #print(g)
    #print(h)
    #print(f)

    #Creating new node and putting values into it
    current_node = Node(movement)
    current_node.f = f
    #Inserting new node into open list
    open_list.append(current_node)

    #Display pyraminx
    #display.display_pyraminx(pyraminx)

#Using heuristic, moves are done on randomized pyraminx until solved
def play(pyraminx):
    g = 0
    closed_list = []
    open_list = []
    #display.display_pyraminx(start)

    #Runs until the pyramnix is solved
    while check(pyraminx) == False:
        start = pyraminx[:]
        g += 1
        #Calculates moves and sends to A* function to calculate heuristic values
        for move in range(1, 13):
            #TOP
            #Turns the top, first level counterclockwise
            if move == 1:
                red = pyraminx[0]
                blue = pyraminx[16]
                yellow = pyraminx[32]

                pyraminx[0] = yellow
                pyraminx[16] = red
                pyraminx[32] = blue

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #Turns the top, first and second level counterclockwise
            elif move == 2:
                red0 = pyraminx[0]
                red1 = pyraminx[1]
                red2 = pyraminx[2]
                red3 = pyraminx[3]
                blue0 = pyraminx[16]
                blue1 = pyraminx[17]
                blue2 = pyraminx[18]
                blue3 = pyraminx[19]
                yellow0 = pyraminx[32]
                yellow1 = pyraminx[33]
                yellow2 = pyraminx[34]
                yellow3 = pyraminx[35]

                pyraminx[0] = yellow0
                pyraminx[1] = yellow1
                pyraminx[2] = yellow2
                pyraminx[3] = yellow3
                pyraminx[16] = red0
                pyraminx[17] = red1
                pyraminx[18] = red2
                pyraminx[19] = red3
                pyraminx[32] = blue0
                pyraminx[33] = blue1
                pyraminx[34] = blue2
                pyraminx[35] = blue3

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #Turn the top, top three levels counterclockwise
            elif move == 3:
                red0 = pyraminx[0]
                red1 = pyraminx[1]
                red2 = pyraminx[2]
                red3 = pyraminx[3]
                red4 = pyraminx[4]
                red5 = pyraminx[5]
                red6 = pyraminx[6]
                red7 = pyraminx[7]
                red8 = pyraminx[8]
                blue0 = pyraminx[16]
                blue1 = pyraminx[17]
                blue2 = pyraminx[18]
                blue3 = pyraminx[19]
                blue4 = pyraminx[20]
                blue5 = pyraminx[21]
                blue6 = pyraminx[22]
                blue7 = pyraminx[23]
                blue8 = pyraminx[24]
                yellow0 = pyraminx[32]
                yellow1 = pyraminx[33]
                yellow2 = pyraminx[34]
                yellow3 = pyraminx[35]
                yellow4 = pyraminx[36]
                yellow5 = pyraminx[37]
                yellow6 = pyraminx[38]
                yellow7 = pyraminx[39]
                yellow8 = pyraminx[40]

                pyraminx[0] = yellow0
                pyraminx[1] = yellow1
                pyraminx[2] = yellow2
                pyraminx[3] = yellow3
                pyraminx[4] = yellow4
                pyraminx[5] = yellow5
                pyraminx[6] = yellow6
                pyraminx[7] = yellow7
                pyraminx[8] = yellow8
                pyraminx[16] = red0
                pyraminx[17] = red1
                pyraminx[18] = red2
                pyraminx[19] = red3
                pyraminx[20] = red4
                pyraminx[21] = red5
                pyraminx[22] = red6
                pyraminx[23] = red7
                pyraminx[24] = red8
                pyraminx[32] = blue0
                pyraminx[33] = blue1
                pyraminx[34] = blue2
                pyraminx[35] = blue3
                pyraminx[36] = blue4
                pyraminx[37] = blue5
                pyraminx[38] = blue6
                pyraminx[39] = blue7
                pyraminx[40] = blue8

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #LEFT
            #Turns the left, first level counterclockwise
            elif move == 4:
                red = pyraminx[15]
                blue = pyraminx[25]
                green = pyraminx[63]

                pyraminx[15] = blue
                pyraminx[25] = green
                pyraminx[63] = red

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #Turns the left, first and second level counterclockwise
            elif move == 5:
                red0 = pyraminx[8]
                red1 = pyraminx[13]
                red2 = pyraminx[14]
                red3 = pyraminx[15]
                blue0 = pyraminx[20]
                blue1 = pyraminx[25]
                blue2 = pyraminx[26]
                blue3 = pyraminx[27]
                green0 = pyraminx[56]
                green1 = pyraminx[61]
                green2 = pyraminx[62]
                green3 = pyraminx[63]

                pyraminx[8] = blue3
                pyraminx[13] = blue0
                pyraminx[14] = blue2
                pyraminx[15] = blue1
                pyraminx[20] = green1
                pyraminx[25] = green3
                pyraminx[26] = green2
                pyraminx[27] = green0
                pyraminx[56] = red0
                pyraminx[61] = red1
                pyraminx[62] = red2
                pyraminx[63] = red3

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #Turn the left, top three levels counterclockwise
            elif move == 6:
                red0 = pyraminx[3]
                red1 = pyraminx[6]
                red2 = pyraminx[7]
                red3 = pyraminx[8]
                red4 = pyraminx[11]
                red5 = pyraminx[12]
                red6 = pyraminx[13]
                red7 = pyraminx[14]
                red8 = pyraminx[15]
                blue0 = pyraminx[17]
                blue1 = pyraminx[20]
                blue2 = pyraminx[21]
                blue3 = pyraminx[22]
                blue4 = pyraminx[25]
                blue5 = pyraminx[26]
                blue6 = pyraminx[27]
                blue7 = pyraminx[28]
                blue8 = pyraminx[29]
                green0 = pyraminx[51]
                green1 = pyraminx[54]
                green2 = pyraminx[55]
                green3 = pyraminx[56]
                green4 = pyraminx[59]
                green5 = pyraminx[60]
                green6 = pyraminx[61]
                green7 = pyraminx[62]
                green8 = pyraminx[63]

                pyraminx[3] = blue8
                pyraminx[6] = blue3
                pyraminx[7] = blue7
                pyraminx[8] = blue6
                pyraminx[11] = blue0
                pyraminx[12] = blue2
                pyraminx[13] = blue1
                pyraminx[14] = blue5
                pyraminx[15] = blue4
                pyraminx[17] = green4
                pyraminx[20] = green6
                pyraminx[21] = green5
                pyraminx[22] = green1
                pyraminx[25] = green8
                pyraminx[26] = green7
                pyraminx[27] = green3
                pyraminx[28] = green2
                pyraminx[29] = green0
                pyraminx[51] = red0
                pyraminx[54] = red1
                pyraminx[55] = red2
                pyraminx[56] = red3
                pyraminx[59] = red4
                pyraminx[60] = red5
                pyraminx[61] = red6
                pyraminx[62] = red7
                pyraminx[63] = red8

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #RIGHT
            #Turns the right, first level counterclockwise
            elif move == 7:
                blue = pyraminx[31]
                yellow = pyraminx[41]
                green = pyraminx[57]

                pyraminx[31] = yellow
                pyraminx[41] = green
                pyraminx[57] = blue

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #Turns the rigth, first and second level counterclockwise
            elif move == 8:
                blue0 = pyraminx[24]
                blue1 = pyraminx[29]
                blue2 = pyraminx[30]
                blue3 = pyraminx[31]
                yellow0 = pyraminx[36]
                yellow1 = pyraminx[41]
                yellow2 = pyraminx[42]
                yellow3 = pyraminx[43]
                green0 = pyraminx[52]
                green1 = pyraminx[57]
                green2 = pyraminx[58]
                green3 = pyraminx[59]

                pyraminx[24] = yellow3
                pyraminx[29] = yellow0
                pyraminx[30] = yellow2
                pyraminx[31] = yellow1
                pyraminx[36] = green0
                pyraminx[41] = green1
                pyraminx[42] = green2
                pyraminx[43] = green3
                pyraminx[52] = blue1
                pyraminx[57] = blue3
                pyraminx[58] = blue2
                pyraminx[59] = blue0

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #Turn the right, top three levels counterclockwise
            elif move == 9:
                blue0 = pyraminx[19]
                blue1 = pyraminx[22]
                blue2 = pyraminx[23]
                blue3 = pyraminx[24]
                blue4 = pyraminx[27]
                blue5 = pyraminx[28]
                blue6 = pyraminx[29]
                blue7 = pyraminx[30]
                blue8 = pyraminx[31]
                yellow0 = pyraminx[33]
                yellow1 = pyraminx[36]
                yellow2 = pyraminx[37]
                yellow3 = pyraminx[38]
                yellow4 = pyraminx[41]
                yellow5 = pyraminx[42]
                yellow6 = pyraminx[43]
                yellow7 = pyraminx[44]
                yellow8 = pyraminx[45]
                green0 = pyraminx[49]
                green1 = pyraminx[52]
                green2 = pyraminx[53]
                green3 = pyraminx[54]
                green4 = pyraminx[57]
                green5 = pyraminx[58]
                green6 = pyraminx[59]
                green7 = pyraminx[60]
                green8 = pyraminx[61]

                pyraminx[19] = yellow8
                pyraminx[22] = yellow3
                pyraminx[23] = yellow7
                pyraminx[24] = yellow6
                pyraminx[27] = yellow0
                pyraminx[28] = yellow2
                pyraminx[29] = yellow1
                pyraminx[30] = yellow5
                pyraminx[31] = yellow4
                pyraminx[33] = green0
                pyraminx[36] = green1
                pyraminx[37] = green2
                pyraminx[38] = green3
                pyraminx[41] = green4
                pyraminx[42] = green5
                pyraminx[43] = green6
                pyraminx[44] = green7
                pyraminx[45] = green8
                pyraminx[49] = blue4
                pyraminx[52] = blue6
                pyraminx[53] = blue5
                pyraminx[54] = blue1
                pyraminx[57] = blue8
                pyraminx[58] = blue7
                pyraminx[59] = blue3
                pyraminx[60] = blue2
                pyraminx[61] = blue0

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #BACK
            #Turns the back, first level counterclockwise
            elif move == 10:
                red = pyraminx[9]
                yellow = pyraminx[47]
                green = pyraminx[48]

                pyraminx[9] = green
                pyraminx[47] = red
                pyraminx[48] = yellow

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #Turns the back, first and second level counterclockwise
            elif move == 11:
                red0 = pyraminx[4]
                red1 = pyraminx[9]
                red2 = pyraminx[10]
                red3 = pyraminx[11]
                yellow0 = pyraminx[40]
                yellow1 = pyraminx[45]
                yellow2 = pyraminx[46]
                yellow3 = pyraminx[47]
                green0 = pyraminx[48]
                green1 = pyraminx[49]
                green2 = pyraminx[50]
                green3 = pyraminx[51]

                pyraminx[4] = green3
                pyraminx[9] = green0
                pyraminx[10] = green2
                pyraminx[11] = green1
                pyraminx[40] = red3
                pyraminx[45] = red0
                pyraminx[46] = red2
                pyraminx[47] = red1
                pyraminx[48] = yellow3
                pyraminx[49] = yellow0
                pyraminx[50] = yellow2
                pyraminx[51] = yellow1

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #Turns the back, top three levels counterclockwise
            elif move == 12:
                red0 = pyraminx[1]
                red1 = pyraminx[4]
                red2 = pyraminx[5]
                red3 = pyraminx[6]
                red4 = pyraminx[9]
                red5 = pyraminx[10]
                red6 = pyraminx[11]
                red7 = pyraminx[12]
                red8 = pyraminx[13]
                yellow0 = pyraminx[35]
                yellow1 = pyraminx[38]
                yellow2 = pyraminx[39]
                yellow3 = pyraminx[40]
                yellow4 = pyraminx[43]
                yellow5 = pyraminx[44]
                yellow6 = pyraminx[45]
                yellow7 = pyraminx[46]
                yellow8 = pyraminx[47]
                green0 = pyraminx[48]
                green1 = pyraminx[49]
                green2 = pyraminx[50]
                green3 = pyraminx[51]
                green4 = pyraminx[52]
                green5 = pyraminx[53]
                green6 = pyraminx[54]
                green7 = pyraminx[55]
                green8 = pyraminx[56]

                pyraminx[1] = green8
                pyraminx[4] = green3
                pyraminx[5] = green7
                pyraminx[6] = green6
                pyraminx[9] = green0
                pyraminx[10] = green2
                pyraminx[11] = green1
                pyraminx[12] = green5
                pyraminx[13] = green4
                pyraminx[35] = red8
                pyraminx[38] = red3
                pyraminx[39] = red7
                pyraminx[40] = red6
                pyraminx[43] = red0
                pyraminx[44] = red2
                pyraminx[45] = red1
                pyraminx[46] = red5
                pyraminx[47] = red4
                pyraminx[48] = yellow8
                pyraminx[49] = yellow3
                pyraminx[50] = yellow7
                pyraminx[51] = yellow6
                pyraminx[52] = yellow0
                pyraminx[53] = yellow2
                pyraminx[54] = yellow1
                pyraminx[55] = yellow5
                pyraminx[56] = yellow4

                astar(pyraminx, g, open_list, closed_list, move)
                pyraminx = start[:]

            #else, invalid move
            else:
                print("Invalid move")

        #Sets current to the first node in open list
        current = open_list[0]

        #For each node in the open list, set current
        #to the current node if the current node's f value
        #is less than current's f value
        for index, item in enumerate(open_list):
            #print(item.move)
            #print(item.f)
            if item.f < current.f:
                current = item

        #Append current node to closed list
        closed_list.append(current)
        del open_list[:]

        #Set pyraminx to move using the lowest heuristic value

        #TOP
        #Turns the top, first level counterclockwise
        if current.move == 1:
            red = pyraminx[0]
            blue = pyraminx[16]
            yellow = pyraminx[32]

            pyraminx[0] = yellow
            pyraminx[16] = red
            pyraminx[32] = blue

        #Turns the top, first and second level counterclockwise
        elif current.move == 2:
            red0 = pyraminx[0]
            red1 = pyraminx[1]
            red2 = pyraminx[2]
            red3 = pyraminx[3]
            blue0 = pyraminx[16]
            blue1 = pyraminx[17]
            blue2 = pyraminx[18]
            blue3 = pyraminx[19]
            yellow0 = pyraminx[32]
            yellow1 = pyraminx[33]
            yellow2 = pyraminx[34]
            yellow3 = pyraminx[35]

            pyraminx[0] = yellow0
            pyraminx[1] = yellow1
            pyraminx[2] = yellow2
            pyraminx[3] = yellow3
            pyraminx[16] = red0
            pyraminx[17] = red1
            pyraminx[18] = red2
            pyraminx[19] = red3
            pyraminx[32] = blue0
            pyraminx[33] = blue1
            pyraminx[34] = blue2
            pyraminx[35] = blue3

        #Turn the top, top three levels counterclockwise
        elif current.move == 3:
            red0 = pyraminx[0]
            red1 = pyraminx[1]
            red2 = pyraminx[2]
            red3 = pyraminx[3]
            red4 = pyraminx[4]
            red5 = pyraminx[5]
            red6 = pyraminx[6]
            red7 = pyraminx[7]
            red8 = pyraminx[8]
            blue0 = pyraminx[16]
            blue1 = pyraminx[17]
            blue2 = pyraminx[18]
            blue3 = pyraminx[19]
            blue4 = pyraminx[20]
            blue5 = pyraminx[21]
            blue6 = pyraminx[22]
            blue7 = pyraminx[23]
            blue8 = pyraminx[24]
            yellow0 = pyraminx[32]
            yellow1 = pyraminx[33]
            yellow2 = pyraminx[34]
            yellow3 = pyraminx[35]
            yellow4 = pyraminx[36]
            yellow5 = pyraminx[37]
            yellow6 = pyraminx[38]
            yellow7 = pyraminx[39]
            yellow8 = pyraminx[40]

            pyraminx[0] = yellow0
            pyraminx[1] = yellow1
            pyraminx[2] = yellow2
            pyraminx[3] = yellow3
            pyraminx[4] = yellow4
            pyraminx[5] = yellow5
            pyraminx[6] = yellow6
            pyraminx[7] = yellow7
            pyraminx[8] = yellow8
            pyraminx[16] = red0
            pyraminx[17] = red1
            pyraminx[18] = red2
            pyraminx[19] = red3
            pyraminx[20] = red4
            pyraminx[21] = red5
            pyraminx[22] = red6
            pyraminx[23] = red7
            pyraminx[24] = red8
            pyraminx[32] = blue0
            pyraminx[33] = blue1
            pyraminx[34] = blue2
            pyraminx[35] = blue3
            pyraminx[36] = blue4
            pyraminx[37] = blue5
            pyraminx[38] = blue6
            pyraminx[39] = blue7
            pyraminx[40] = blue8

        #LEFT
        #Turns the left, first level counterclockwise
        elif current.move == 4:
            red = pyraminx[15]
            blue = pyraminx[25]
            green = pyraminx[63]

            pyraminx[15] = blue
            pyraminx[25] = green
            pyraminx[63] = red

        #Turns the left, first and second level counterclockwise
        elif current.move == 5:
            red0 = pyraminx[8]
            red1 = pyraminx[13]
            red2 = pyraminx[14]
            red3 = pyraminx[15]
            blue0 = pyraminx[20]
            blue1 = pyraminx[25]
            blue2 = pyraminx[26]
            blue3 = pyraminx[27]
            green0 = pyraminx[56]
            green1 = pyraminx[61]
            green2 = pyraminx[62]
            green3 = pyraminx[63]

            pyraminx[8] = blue3
            pyraminx[13] = blue0
            pyraminx[14] = blue2
            pyraminx[15] = blue1
            pyraminx[20] = green1
            pyraminx[25] = green3
            pyraminx[26] = green2
            pyraminx[27] = green0
            pyraminx[56] = red0
            pyraminx[61] = red1
            pyraminx[62] = red2
            pyraminx[63] = red3

        #Turn the left, top three levels counterclockwise
        elif current.move == 6:
            red0 = pyraminx[3]
            red1 = pyraminx[6]
            red2 = pyraminx[7]
            red3 = pyraminx[8]
            red4 = pyraminx[11]
            red5 = pyraminx[12]
            red6 = pyraminx[13]
            red7 = pyraminx[14]
            red8 = pyraminx[15]
            blue0 = pyraminx[17]
            blue1 = pyraminx[20]
            blue2 = pyraminx[21]
            blue3 = pyraminx[22]
            blue4 = pyraminx[25]
            blue5 = pyraminx[26]
            blue6 = pyraminx[27]
            blue7 = pyraminx[28]
            blue8 = pyraminx[29]
            green0 = pyraminx[51]
            green1 = pyraminx[54]
            green2 = pyraminx[55]
            green3 = pyraminx[56]
            green4 = pyraminx[59]
            green5 = pyraminx[60]
            green6 = pyraminx[61]
            green7 = pyraminx[62]
            green8 = pyraminx[63]

            pyraminx[3] = blue8
            pyraminx[6] = blue3
            pyraminx[7] = blue7
            pyraminx[8] = blue6
            pyraminx[11] = blue0
            pyraminx[12] = blue2
            pyraminx[13] = blue1
            pyraminx[14] = blue5
            pyraminx[15] = blue4
            pyraminx[17] = green4
            pyraminx[20] = green6
            pyraminx[21] = green5
            pyraminx[22] = green1
            pyraminx[25] = green8
            pyraminx[26] = green7
            pyraminx[27] = green3
            pyraminx[28] = green2
            pyraminx[29] = green0
            pyraminx[51] = red0
            pyraminx[54] = red1
            pyraminx[55] = red2
            pyraminx[56] = red3
            pyraminx[59] = red4
            pyraminx[60] = red5
            pyraminx[61] = red6
            pyraminx[62] = red7
            pyraminx[63] = red8

        #RIGHT
        #Turns the right, first level counterclockwise
        elif current.move == 7:
            blue = pyraminx[31]
            yellow = pyraminx[41]
            green = pyraminx[57]

            pyraminx[31] = yellow
            pyraminx[41] = green
            pyraminx[57] = blue

        #Turns the rigth, first and second level counterclockwise
        elif current.move == 8:
            blue0 = pyraminx[24]
            blue1 = pyraminx[29]
            blue2 = pyraminx[30]
            blue3 = pyraminx[31]
            yellow0 = pyraminx[36]
            yellow1 = pyraminx[41]
            yellow2 = pyraminx[42]
            yellow3 = pyraminx[43]
            green0 = pyraminx[52]
            green1 = pyraminx[57]
            green2 = pyraminx[58]
            green3 = pyraminx[59]

            pyraminx[24] = yellow3
            pyraminx[29] = yellow0
            pyraminx[30] = yellow2
            pyraminx[31] = yellow1
            pyraminx[36] = green0
            pyraminx[41] = green1
            pyraminx[42] = green2
            pyraminx[43] = green3
            pyraminx[52] = blue1
            pyraminx[57] = blue3
            pyraminx[58] = blue2
            pyraminx[59] = blue0

        #Turn the right, top three levels counterclockwise
        elif current.move == 9:
            blue0 = pyraminx[19]
            blue1 = pyraminx[22]
            blue2 = pyraminx[23]
            blue3 = pyraminx[24]
            blue4 = pyraminx[27]
            blue5 = pyraminx[28]
            blue6 = pyraminx[29]
            blue7 = pyraminx[30]
            blue8 = pyraminx[31]
            yellow0 = pyraminx[33]
            yellow1 = pyraminx[36]
            yellow2 = pyraminx[37]
            yellow3 = pyraminx[38]
            yellow4 = pyraminx[41]
            yellow5 = pyraminx[42]
            yellow6 = pyraminx[43]
            yellow7 = pyraminx[44]
            yellow8 = pyraminx[45]
            green0 = pyraminx[49]
            green1 = pyraminx[52]
            green2 = pyraminx[53]
            green3 = pyraminx[54]
            green4 = pyraminx[57]
            green5 = pyraminx[58]
            green6 = pyraminx[59]
            green7 = pyraminx[60]
            green8 = pyraminx[61]

            pyraminx[19] = yellow8
            pyraminx[22] = yellow3
            pyraminx[23] = yellow7
            pyraminx[24] = yellow6
            pyraminx[27] = yellow0
            pyraminx[28] = yellow2
            pyraminx[29] = yellow1
            pyraminx[30] = yellow5
            pyraminx[31] = yellow4
            pyraminx[33] = green0
            pyraminx[36] = green1
            pyraminx[37] = green2
            pyraminx[38] = green3
            pyraminx[41] = green4
            pyraminx[42] = green5
            pyraminx[43] = green6
            pyraminx[44] = green7
            pyraminx[45] = green8
            pyraminx[49] = blue4
            pyraminx[52] = blue6
            pyraminx[53] = blue5
            pyraminx[54] = blue1
            pyraminx[57] = blue8
            pyraminx[58] = blue7
            pyraminx[59] = blue3
            pyraminx[60] = blue2
            pyraminx[61] = blue0


        #BACK
        #Turns the back, first level counterclockwise
        elif current.move == 10:
            red = pyraminx[9]
            yellow = pyraminx[47]
            green = pyraminx[48]

            pyraminx[9] = green
            pyraminx[47] = red
            pyraminx[48] = yellow

        #Turns the back, first and second level counterclockwise
        elif current.move == 11:
            red0 = pyraminx[4]
            red1 = pyraminx[9]
            red2 = pyraminx[10]
            red3 = pyraminx[11]
            yellow0 = pyraminx[40]
            yellow1 = pyraminx[45]
            yellow2 = pyraminx[46]
            yellow3 = pyraminx[47]
            green0 = pyraminx[48]
            green1 = pyraminx[49]
            green2 = pyraminx[50]
            green3 = pyraminx[51]

            pyraminx[4] = green3
            pyraminx[9] = green0
            pyraminx[10] = green2
            pyraminx[11] = green1
            pyraminx[40] = red3
            pyraminx[45] = red0
            pyraminx[46] = red2
            pyraminx[47] = red1
            pyraminx[48] = yellow3
            pyraminx[49] = yellow0
            pyraminx[50] = yellow2
            pyraminx[51] = yellow1

        #Turns the back, top three levels counterclockwise
        elif current.move == 12:
            red0 = pyraminx[1]
            red1 = pyraminx[4]
            red2 = pyraminx[5]
            red3 = pyraminx[6]
            red4 = pyraminx[9]
            red5 = pyraminx[10]
            red6 = pyraminx[11]
            red7 = pyraminx[12]
            red8 = pyraminx[13]
            yellow0 = pyraminx[35]
            yellow1 = pyraminx[38]
            yellow2 = pyraminx[39]
            yellow3 = pyraminx[40]
            yellow4 = pyraminx[43]
            yellow5 = pyraminx[44]
            yellow6 = pyraminx[45]
            yellow7 = pyraminx[46]
            yellow8 = pyraminx[47]
            green0 = pyraminx[48]
            green1 = pyraminx[49]
            green2 = pyraminx[50]
            green3 = pyraminx[51]
            green4 = pyraminx[52]
            green5 = pyraminx[53]
            green6 = pyraminx[54]
            green7 = pyraminx[55]
            green8 = pyraminx[56]

            pyraminx[1] = green8
            pyraminx[4] = green3
            pyraminx[5] = green7
            pyraminx[6] = green6
            pyraminx[9] = green0
            pyraminx[10] = green2
            pyraminx[11] = green1
            pyraminx[12] = green5
            pyraminx[13] = green4
            pyraminx[35] = red8
            pyraminx[38] = red3
            pyraminx[39] = red7
            pyraminx[40] = red6
            pyraminx[43] = red0
            pyraminx[44] = red2
            pyraminx[45] = red1
            pyraminx[46] = red5
            pyraminx[47] = red4
            pyraminx[48] = yellow8
            pyraminx[49] = yellow3
            pyraminx[50] = yellow7
            pyraminx[51] = yellow6
            pyraminx[52] = yellow0
            pyraminx[53] = yellow2
            pyraminx[54] = yellow1
            pyraminx[55] = yellow5
            pyraminx[56] = yellow4

        #for index, item in enumerate(closed_list):
        #    print(item.move)
        #    print(item.f)

        #display.display_pyraminx(pyraminx)
