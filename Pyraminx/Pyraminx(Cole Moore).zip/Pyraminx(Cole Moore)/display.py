#Function to print the model of the pyraminx
#def faces(red, blue, yellow, green):
                                    #red                                                                    #blue                                                                             #yellow
#    print                   "     ", red[0],                                             "               ", blue[0],                                                       "               ", yellow[0]

#    print             "   ", red[1], red[2], red[3],                                "           ", blue[1], blue[2], blue[3],                                       "           ", yellow[1], yellow[2], yellow[3]

#    print       " ", red[4], red[5], red[6], red[7], red[8],                   "       ", blue[4], blue[5], blue[6], blue[7], blue[8],                       "       ", yellow[4], yellow[5], yellow[6], yellow[7], yellow[8]

#    print red[9], red[10], red[11], red[12], red[13], red[14], red[15], "   ", blue[9], blue[10], blue[11], blue[12], blue[13], blue[14], blue[15], "   ", yellow[9], yellow[10], yellow[11], yellow[12], yellow[13], yellow[14], yellow[15]
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#    print                                              "                 ", green[15], green[14], green[13], green[12], green[11], green[10], green[9]

#    print                                                         "                   ", green[8], green[7], green[6], green[5], green[4]

#    print                                                                 "                     ", green[3], green[2], green[1]

#    print                                                                         "                       ", green[0]
                                                                                                            #green

#print the current pyraminx model
def display_pyraminx(pyraminx):
                                          #red face                                                                                                             #blue face                                                                                              #yellow face
        print                   "     ", pyraminx[0],                                                                                        "               ", pyraminx[16],                                                                         "               ", pyraminx[32]

        print             "   ", pyraminx[1], pyraminx[2], pyraminx[3],                                                            "           ", pyraminx[17], pyraminx[18], pyraminx[19],                                                 "           ", pyraminx[33], pyraminx[34], pyraminx[35]

        print       " ", pyraminx[4], pyraminx[5], pyraminx[6], pyraminx[7], pyraminx[8],                                "       ", pyraminx[20], pyraminx[21], pyraminx[22], pyraminx[23], pyraminx[24],                         "       ", pyraminx[36], pyraminx[37], pyraminx[38], pyraminx[39], pyraminx[40]

        print pyraminx[9], pyraminx[10], pyraminx[11], pyraminx[12], pyraminx[13], pyraminx[14], pyraminx[15], "   ", pyraminx[25], pyraminx[26], pyraminx[27], pyraminx[28], pyraminx[29], pyraminx[30], pyraminx[31], "   ", pyraminx[41], pyraminx[42], pyraminx[43], pyraminx[44], pyraminx[45], pyraminx[46], pyraminx[47]
    #--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        print                                                                                    "                 ", pyraminx[63], pyraminx[62], pyraminx[61], pyraminx[60], pyraminx[59], pyraminx[58], pyraminx[57]

        print                                                                                                "                   ", pyraminx[56], pyraminx[55], pyraminx[54], pyraminx[53], pyraminx[52]

        print                                                                                                            "                     ", pyraminx[51], pyraminx[50], pyraminx[49]

        print                                                                                                                        "                       ", pyraminx[48]
                                                                                                                                                                #green face
