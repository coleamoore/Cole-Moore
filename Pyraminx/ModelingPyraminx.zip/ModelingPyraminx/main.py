import display
import solve
import randomizer

#Sets all of the sides of the pyraminx as lists
red = ['r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r']
blue = ['b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b']
yellow = ['y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y']
green = ['g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g']

#Combines all of the faces of the pyraminx into one list
pyraminx = red + blue + yellow + green

#Calls function to print pyraminx
#faces(red, blue, yellow, green)

#Displays moveset
solve.moveset()
#Calls the function to print the pyraminx model
display.display_pyraminx(pyraminx)

#Calls function to randomize pyraminx with inputed number of moves from user
randomizer.randomize(pyraminx)

#Plays the game until the puzzle is solved (all sides are a solid color)
#(NOTE: All moves are in relation to the blue, front-facing side of the pyraminx)

#NOTE: For the first assignment, all lines below this can be commented out
#while solve.play(pyraminx) == False:
#    pass
#
#print("The pyraminx is solved!")
