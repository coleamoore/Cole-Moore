import display

#Check if pyraminx is solved (all sides are a solid color)
def check(pyraminx):
    if pyraminx == ['r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g']:
        return True
    else:
        return False

#Print out all possible moves
def moveset():
    print("The first letter stands for the position of the tips relative to the front-facing blue side.")
    print("The number after the letter represents how many levels from that tip down will be rotated per move.")
    print("NOTE: ALL ROTATIONS WILL BE CLOCKWISE RELATIVE TO THE TIP CHOSEN")
    print("T: top")
    print("T1")
    print("T2")
    print("T3")
    print("L: left")
    print("L1")
    print("L2")
    print("L3")
    print("R: right")
    print("R1")
    print("R2")
    print("R3")
    print("B: back")
    print("B1")
    print("B2")
    print("B3")

#Allows player to input moves until pyraminx is solved
#NOTE: will change to counterclockwise later in solving assignment
def play(pyraminx):
    #Gets move input from user
    move = raw_input("Please enter a move: ").upper()
    #print(move)

    #TOP
    #Turns the top, first level clockwise
    if move == "T1":
        red = pyraminx[0]
        blue = pyraminx[16]
        yellow = pyraminx[32]

        pyraminx[0] = blue
        pyraminx[16] = yellow
        pyraminx[32] = red

    #Turns the top, first and second level clockwise
    elif move == "T2":
        red0 = pyraminx[0]
        red1 = pyraminx[1]
        red2 = pyraminx[2]
        red3 = pyraminx[3]
        blue0 = pyraminx[16]
        blue1 = pyraminx[17]
        blue2 = pyraminx[18]
        blue3 = pyraminx[19]
        yellow0 = pyraminx[32]
        yellow1 = pyraminx[33]
        yellow2 = pyraminx[34]
        yellow3 = pyraminx[35]

        pyraminx[0] = blue0
        pyraminx[1] = blue1
        pyraminx[2] = blue2
        pyraminx[3] = blue3
        pyraminx[16] = yellow0
        pyraminx[17] = yellow1
        pyraminx[18] = yellow2
        pyraminx[19] = yellow3
        pyraminx[32] = red0
        pyraminx[33] = red1
        pyraminx[34] = red2
        pyraminx[35] = red3

    #Turn the top, top three levels clockwise
    elif move == "T3":
        red0 = pyraminx[0]
        red1 = pyraminx[1]
        red2 = pyraminx[2]
        red3 = pyraminx[3]
        red4 = pyraminx[4]
        red5 = pyraminx[5]
        red6 = pyraminx[6]
        red7 = pyraminx[7]
        red8 = pyraminx[8]
        blue0 = pyraminx[16]
        blue1 = pyraminx[17]
        blue2 = pyraminx[18]
        blue3 = pyraminx[19]
        blue4 = pyraminx[20]
        blue5 = pyraminx[21]
        blue6 = pyraminx[22]
        blue7 = pyraminx[23]
        blue8 = pyraminx[24]
        yellow0 = pyraminx[32]
        yellow1 = pyraminx[33]
        yellow2 = pyraminx[34]
        yellow3 = pyraminx[35]
        yellow4 = pyraminx[36]
        yellow5 = pyraminx[37]
        yellow6 = pyraminx[38]
        yellow7 = pyraminx[39]
        yellow8 = pyraminx[40]

        pyraminx[0] = blue0
        pyraminx[1] = blue1
        pyraminx[2] = blue2
        pyraminx[3] = blue3
        pyraminx[4] = blue4
        pyraminx[5] = blue5
        pyraminx[6] = blue6
        pyraminx[7] = blue7
        pyraminx[8] = blue8
        pyraminx[16] = yellow0
        pyraminx[17] = yellow1
        pyraminx[18] = yellow2
        pyraminx[19] = yellow3
        pyraminx[20] = yellow4
        pyraminx[21] = yellow5
        pyraminx[22] = yellow6
        pyraminx[23] = yellow7
        pyraminx[24] = yellow8
        pyraminx[32] = red0
        pyraminx[33] = red1
        pyraminx[34] = red2
        pyraminx[35] = red3
        pyraminx[36] = red4
        pyraminx[37] = red5
        pyraminx[38] = red6
        pyraminx[39] = red7
        pyraminx[40] = red8

    #LEFT
    #Turns the left, first level clockwise
    elif move == "L1":
        red = pyraminx[15]
        blue = pyraminx[25]
        green = pyraminx[63]

        pyraminx[15] = green
        pyraminx[25] = red
        pyraminx[63] = blue

    #Turns the left, first and second level clockwise
    elif move == "L2":
        red0 = pyraminx[8]
        red1 = pyraminx[13]
        red2 = pyraminx[14]
        red3 = pyraminx[15]
        blue0 = pyraminx[20]
        blue1 = pyraminx[25]
        blue2 = pyraminx[26]
        blue3 = pyraminx[27]
        green0 = pyraminx[56]
        green1 = pyraminx[61]
        green2 = pyraminx[62]
        green3 = pyraminx[63]

        pyraminx[8] = green0
        pyraminx[13] = green1
        pyraminx[14] = green2
        pyraminx[15] = green3
        pyraminx[20] = red1
        pyraminx[25] = red3
        pyraminx[26] = red2
        pyraminx[27] = red0
        pyraminx[56] = blue3
        pyraminx[61] = blue0
        pyraminx[62] = blue2
        pyraminx[63] = blue1

    #Turn the left, top three levels clockwise
    elif move == "L3":
        red0 = pyraminx[3]
        red1 = pyraminx[6]
        red2 = pyraminx[7]
        red3 = pyraminx[8]
        red4 = pyraminx[11]
        red5 = pyraminx[12]
        red6 = pyraminx[13]
        red7 = pyraminx[14]
        red8 = pyraminx[15]
        blue0 = pyraminx[17]
        blue1 = pyraminx[20]
        blue2 = pyraminx[21]
        blue3 = pyraminx[22]
        blue4 = pyraminx[25]
        blue5 = pyraminx[26]
        blue6 = pyraminx[27]
        blue7 = pyraminx[28]
        blue8 = pyraminx[29]
        green0 = pyraminx[51]
        green1 = pyraminx[54]
        green2 = pyraminx[55]
        green3 = pyraminx[56]
        green4 = pyraminx[59]
        green5 = pyraminx[60]
        green6 = pyraminx[61]
        green7 = pyraminx[62]
        green8 = pyraminx[63]

        pyraminx[3] = green0
        pyraminx[6] = green1
        pyraminx[7] = green2
        pyraminx[8] = green3
        pyraminx[11] = green4
        pyraminx[12] = green5
        pyraminx[13] = green6
        pyraminx[14] = green7
        pyraminx[15] = green8
        pyraminx[17] = red4
        pyraminx[20] = red6
        pyraminx[21] = red5
        pyraminx[22] = red1
        pyraminx[25] = red8
        pyraminx[26] = red7
        pyraminx[27] = red3
        pyraminx[28] = red2
        pyraminx[29] = red0
        pyraminx[51] = blue8
        pyraminx[54] = blue3
        pyraminx[55] = blue7
        pyraminx[56] = blue6
        pyraminx[59] = blue0
        pyraminx[60] = blue2
        pyraminx[61] = blue1
        pyraminx[62] = blue5
        pyraminx[63] = blue4

    #RIGHT
    #Turns the right, first level clockwise
    elif move == "R1":
        blue = pyraminx[31]
        yellow = pyraminx[41]
        green = pyraminx[57]

        pyraminx[31] = green
        pyraminx[41] = blue
        pyraminx[57] = yellow

    #Turns the rigth, first and second level clockwise
    elif move == "R2":
        blue0 = pyraminx[24]
        blue1 = pyraminx[29]
        blue2 = pyraminx[30]
        blue3 = pyraminx[31]
        yellow0 = pyraminx[36]
        yellow1 = pyraminx[41]
        yellow2 = pyraminx[42]
        yellow3 = pyraminx[43]
        green0 = pyraminx[52]
        green1 = pyraminx[57]
        green2 = pyraminx[58]
        green3 = pyraminx[59]

        pyraminx[24] = green3
        pyraminx[29] = green0
        pyraminx[30] = green2
        pyraminx[31] = green1
        pyraminx[36] = blue1
        pyraminx[41] = blue3
        pyraminx[42] = blue2
        pyraminx[43] = blue0
        pyraminx[52] = yellow0
        pyraminx[57] = yellow1
        pyraminx[58] = yellow2
        pyraminx[59] = yellow3

    #Turn the right, top three levels clockwise
    elif move == "R3":
        blue0 = pyraminx[19]
        blue1 = pyraminx[22]
        blue2 = pyraminx[23]
        blue3 = pyraminx[24]
        blue4 = pyraminx[27]
        blue5 = pyraminx[28]
        blue6 = pyraminx[29]
        blue7 = pyraminx[30]
        blue8 = pyraminx[31]
        yellow0 = pyraminx[33]
        yellow1 = pyraminx[36]
        yellow2 = pyraminx[37]
        yellow3 = pyraminx[38]
        yellow4 = pyraminx[41]
        yellow5 = pyraminx[42]
        yellow6 = pyraminx[43]
        yellow7 = pyraminx[44]
        yellow8 = pyraminx[45]
        green0 = pyraminx[49]
        green1 = pyraminx[52]
        green2 = pyraminx[53]
        green3 = pyraminx[54]
        green4 = pyraminx[57]
        green5 = pyraminx[58]
        green6 = pyraminx[59]
        green7 = pyraminx[60]
        green8 = pyraminx[61]

        pyraminx[19] = green8
        pyraminx[22] = green3
        pyraminx[23] = green7
        pyraminx[24] = green6
        pyraminx[27] = green0
        pyraminx[28] = green2
        pyraminx[29] = green1
        pyraminx[30] = green5
        pyraminx[31] = green4
        pyraminx[33] = blue4
        pyraminx[36] = blue6
        pyraminx[37] = blue5
        pyraminx[38] = blue1
        pyraminx[41] = blue8
        pyraminx[42] = blue7
        pyraminx[43] = blue3
        pyraminx[44] = blue2
        pyraminx[45] = blue0
        pyraminx[49] = yellow0
        pyraminx[52] = yellow1
        pyraminx[53] = yellow2
        pyraminx[54] = yellow3
        pyraminx[57] = yellow4
        pyraminx[58] = yellow5
        pyraminx[59] = yellow6
        pyraminx[60] = yellow7
        pyraminx[61] = yellow8

    #BACK
    #Turns the back, first level clockwise
    elif move == "B1":
        red = pyraminx[9]
        yellow = pyraminx[47]
        green = pyraminx[48]

        pyraminx[9] = yellow
        pyraminx[47] = green
        pyraminx[48] = red

    #Turns the back, first and second level clockwise
    elif move == "B2":
        red0 = pyraminx[4]
        red1 = pyraminx[9]
        red2 = pyraminx[10]
        red3 = pyraminx[11]
        yellow0 = pyraminx[40]
        yellow1 = pyraminx[45]
        yellow2 = pyraminx[46]
        yellow3 = pyraminx[47]
        green0 = pyraminx[48]
        green1 = pyraminx[49]
        green2 = pyraminx[50]
        green3 = pyraminx[51]

        pyraminx[4] = yellow1
        pyraminx[9] = yellow3
        pyraminx[10] = yellow2
        pyraminx[11] = yellow0
        pyraminx[40] = green1
        pyraminx[45] = green3
        pyraminx[46] = green2
        pyraminx[47] = green0
        pyraminx[48] = red1
        pyraminx[49] = red3
        pyraminx[50] = red2
        pyraminx[51] = red0

    #Turns the back, top three levels clockwise
    elif move == "B3":
        red0 = pyraminx[1]
        red1 = pyraminx[4]
        red2 = pyraminx[5]
        red3 = pyraminx[6]
        red4 = pyraminx[9]
        red5 = pyraminx[10]
        red6 = pyraminx[11]
        red7 = pyraminx[12]
        red8 = pyraminx[13]
        yellow0 = pyraminx[35]
        yellow1 = pyraminx[38]
        yellow2 = pyraminx[39]
        yellow3 = pyraminx[40]
        yellow4 = pyraminx[43]
        yellow5 = pyraminx[44]
        yellow6 = pyraminx[45]
        yellow7 = pyraminx[46]
        yellow8 = pyraminx[47]
        green0 = pyraminx[48]
        green1 = pyraminx[49]
        green2 = pyraminx[50]
        green3 = pyraminx[51]
        green4 = pyraminx[52]
        green5 = pyraminx[53]
        green6 = pyraminx[54]
        green7 = pyraminx[55]
        green8 = pyraminx[56]

        pyraminx[1] = yellow4
        pyraminx[4] = yellow6
        pyraminx[5] = yellow5
        pyraminx[6] = yellow1
        pyraminx[9] = yellow8
        pyraminx[10] = yellow7
        pyraminx[11] = yellow3
        pyraminx[12] = yellow2
        pyraminx[13] = yellow0
        pyraminx[35] = green4
        pyraminx[38] = green6
        pyraminx[39] = green5
        pyraminx[40] = green1
        pyraminx[43] = green8
        pyraminx[44] = green7
        pyraminx[45] = green3
        pyraminx[46] = green2
        pyraminx[47] = green0
        pyraminx[48] = red4
        pyraminx[49] = red6
        pyraminx[50] = red5
        pyraminx[51] = red1
        pyraminx[52] = red8
        pyraminx[53] = red7
        pyraminx[54] = red3
        pyraminx[55] = red2
        pyraminx[56] = red0

    #else, invalid move
    else:
        print("Invalid move")


    display.display_pyraminx(pyraminx)
    solved = check(pyraminx)
    return solved
